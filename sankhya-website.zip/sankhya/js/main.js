const exams=["RBI Grade B","SEBI Grade A","NABARD Grade A","IRDAI Assistant Manager","PFRDA Grade A","IFSCA Grade A","FCI","UPSC EPFO/APFC","JAIIB / CAIIB"];
const fam={"RBI Grade B":"Regulatory","SEBI Grade A":"Regulatory","NABARD Grade A":"Regulatory","IRDAI Assistant Manager":"Regulatory","PFRDA Grade A":"Regulatory","IFSCA Grade A":"Regulatory","FCI":"Regulatory","UPSC EPFO/APFC":"UPSC","JAIIB / CAIIB":"Banking"};
const courses=exams.map(e=>({t:e+" Complete Course",f:fam[e],d:"[Course description placeholder]",p:"₹ [price]",r:"[rating]",i:"[instructor]"}));
const res=["Previous year papers","Current affairs compilations","Video lectures","E-books","Strategy workshops","Free demo classes"];
const ment=["Weekly mentor calls","Discussion forum","Email, phone & ticket support","Live strategy workshops"];
const faq=[["How does mentorship work?","[Answer placeholder: edit in data]"],["Can I try before I buy?","[Answer placeholder]"],["Are classes recorded?","[Answer placeholder]"],["How do I contact support?","[Answer placeholder]"]];
const $=s=>document.querySelector(s);
const card=(t,d,x="")=>`<div class="card">${x}<h3>${t}</h3><p>${d}</p></div>`;
$("#eg").innerHTML=exams.map(e=>card(e,"View courses &amp; tests →")).join("");
$("#rg").innerHTML=res.map(r=>card(r,"[Description placeholder]")).join("");
$("#mg").innerHTML=ment.map(r=>card(r,"[Description placeholder]")).join("");
$("#fq").innerHTML=faq.map(f=>`<details><summary>${f[0]}</summary><p>${f[1]}</p></details>`).join("");
let cur="All";const fams=["All","Regulatory","UPSC","Banking"];
function rc(){ $("#tabs").innerHTML=fams.map(f=>`<button role="tab" aria-selected="${f==cur}" onclick="cur='${f}';rc()">${f}</button>`).join("");
$("#cg").innerHTML=courses.filter(c=>cur=="All"||c.f==cur).map(c=>card(c.t,`${c.d}<br><span class="ph">${c.i} · ${c.r} · ${c.p}</span><br><br><button class="btn" onclick="openM('Enrol')">Enrol</button>`,`<span class="tag">${c.f}</span>`)).join("")}
rc();
const qs=[["Which body regulates the Indian securities market? (mock)",["RBI","SEBI","IRDAI","NABARD"],1],["Which body regulates insurance? (mock)",["IRDAI","SEBI","FCI","PFRDA"],0],["Which body regulates pensions? (mock)",["PFRDA","IFSCA","RBI","FCI"],0]];
let qi=0,sc=0;
function rq(){const q=$("#quiz");if(qi>=qs.length){q.innerHTML=`<h3>Score: ${sc}/${qs.length}</h3><button class="btn" onclick="qi=0;sc=0;rq()">Retry</button>`;return}
const [t,o,a]=qs[qi];q.innerHTML=`<h3>Q${qi+1}. ${t}</h3>`+o.map((x,i)=>`<button class="btn o" style="display:block;margin:8px 0;width:100%;text-align:left" onclick="sc+=${i==a?1:0};qi++;rq()">${x}</button>`).join("")}
rq();
const mb=$("#mb");mb.onclick=()=>{const o=$("#nav").classList.toggle("open");mb.setAttribute("aria-expanded",o)};
$("#nav").onclick=e=>{if(e.target.tagName=="A")$("#nav").classList.remove("open")};
function openM(t){$("#mt").textContent=t;$("#m").hidden=false}function closeM(){$("#m").hidden=true}
closeM();document.addEventListener("keydown",e=>{if(e.key=="Escape")closeM()});
